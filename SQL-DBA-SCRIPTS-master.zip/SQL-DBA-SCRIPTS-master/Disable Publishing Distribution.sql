use [master]
exec sp_dropdistributor @no_checks = 1
GO
