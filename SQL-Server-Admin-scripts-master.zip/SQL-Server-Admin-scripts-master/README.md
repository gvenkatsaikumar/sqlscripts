## SQL-Server-Admin-scripts

Compilation of Scripts (mostly SQL ones) used to administer SQL Server

Please check also the [wiki](https://github.com/beumof/SQL-Server-Admin-scripts/wiki) as it's a guide to administer SQL Server.
