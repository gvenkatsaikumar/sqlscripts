# File: Infrasctructure_CheckConnectivity.ps1
# Compilled in https://github.com/beumof/SQL-Server-Admin-scripts
# Added in 2022-05-13

#Replaces telnet check in DOS
Test-NetConnection <FQDN> -Port <port>