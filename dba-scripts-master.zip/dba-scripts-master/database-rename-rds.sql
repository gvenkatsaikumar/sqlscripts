EXEC rdsadmin.dbo.rds_modify_db_name N'FOO', N'BAR'
GO