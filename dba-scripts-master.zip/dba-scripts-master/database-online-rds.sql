EXEC rdsadmin.dbo.rds_set_database_online db_name;
GO
