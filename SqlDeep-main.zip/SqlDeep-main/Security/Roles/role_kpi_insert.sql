CREATE ROLE [role_kpi_insert]
AUTHORIZATION [dbo]
GO
