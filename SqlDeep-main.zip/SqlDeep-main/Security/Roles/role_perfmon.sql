CREATE ROLE [role_perfmon]
AUTHORIZATION [dbo]
GO
