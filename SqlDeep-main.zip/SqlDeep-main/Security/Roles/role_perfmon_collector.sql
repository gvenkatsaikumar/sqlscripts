CREATE ROLE [role_perfmon_collector]
AUTHORIZATION [dbo]
GO
