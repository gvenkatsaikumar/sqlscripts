CREATE ROLE [role_policy_check]
AUTHORIZATION [dbo]
GO
