CREATE ROLE [role_kpi_select]
AUTHORIZATION [dbo]
GO
