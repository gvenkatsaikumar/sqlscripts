CREATE SCHEMA [maintenance]
AUTHORIZATION [db_owner]
GO
