![](https://github.com/SiavashGolchoobian/SqlDeep/blob/main/_Documents/images/SQLDeepCircleV2_Transparent_150.png)

SqlDeep tool (prevousely known as DBA tool) developed in 2013 and after few years in 2019 it's ownership was transferred to  “[sqldeep.com](https://www.sqldeep.com)” team and this product renamed to "SqlDeep tool", finally in 2021 this project was published on [github.com](https://github.com) as an open-sourced project.  
