INSERT INTO [maintenance].[Lookup_VariableSource] ([Name]) VALUES (N'BAKCUPRECORD')
INSERT INTO [maintenance].[Lookup_VariableSource] ([Name]) VALUES (N'TIMEFLAGS')
