INSERT INTO [maintenance].[Lookup_TransferSeries] ([TransferSeries]) VALUES (N'DailyExport')
INSERT INTO [maintenance].[Lookup_TransferSeries] ([TransferSeries]) VALUES (N'DailyFullBackup')
INSERT INTO [maintenance].[Lookup_TransferSeries] ([TransferSeries]) VALUES (N'HourlyLogBackup')
