INSERT INTO [maintenance].[Lookup_ExistenceCheck] ([ExistenceCheck]) VALUES (N'Check All')
INSERT INTO [maintenance].[Lookup_ExistenceCheck] ([ExistenceCheck]) VALUES (N'Check Catalog Record Existence')
INSERT INTO [maintenance].[Lookup_ExistenceCheck] ([ExistenceCheck]) VALUES (N'Check Physical File Existence')
INSERT INTO [maintenance].[Lookup_ExistenceCheck] ([ExistenceCheck]) VALUES (N'No Check')
