INSERT INTO [maintenance].[Lookup_BackupTypes] ([BackupType], [Abbreviation]) VALUES (N'DIFF', N'F')
INSERT INTO [maintenance].[Lookup_BackupTypes] ([BackupType], [Abbreviation]) VALUES (N'EXPORT', N'E')
INSERT INTO [maintenance].[Lookup_BackupTypes] ([BackupType], [Abbreviation]) VALUES (N'FULL', N'D')
INSERT INTO [maintenance].[Lookup_BackupTypes] ([BackupType], [Abbreviation]) VALUES (N'LOG', N'L')
