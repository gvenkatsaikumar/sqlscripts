EXEC sp_addextendedproperty N'_TempSnapLocation', N'U:\Databases\Temp\CheckDB', NULL, NULL, NULL, NULL, NULL, NULL
GO
