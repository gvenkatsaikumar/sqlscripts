EXEC sp_addextendedproperty N'_AlwaysOnAlerts', N'<alerts>
	<alert name="AlertName01" />
	<alert name="AlertName02" />
</alerts>', NULL, NULL, NULL, NULL, NULL, NULL
GO
