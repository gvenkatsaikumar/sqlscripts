EXEC sp_addextendedproperty N'_ShrinkLogToSizeMB', N'200', NULL, NULL, NULL, NULL, NULL, NULL
GO
