EXEC sp_addextendedproperty N'Developer', N'http://www.sqldeep.com', NULL, NULL, NULL, NULL, NULL, NULL
GO
