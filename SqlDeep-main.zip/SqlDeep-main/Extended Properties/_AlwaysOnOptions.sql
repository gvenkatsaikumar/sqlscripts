EXEC sp_addextendedproperty N'_AlwaysOnOptions', N' <options>
   <option name="TRUSTWORTHY" value="OFF" run_on_primary="1" run_on_secondary="0" />
 </options>', NULL, NULL, NULL, NULL, NULL, NULL
GO
