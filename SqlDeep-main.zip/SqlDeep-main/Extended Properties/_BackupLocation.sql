EXEC sp_addextendedproperty N'_BackupLocation', N'U:\Databases\Backup', NULL, NULL, NULL, NULL, NULL, NULL
GO
