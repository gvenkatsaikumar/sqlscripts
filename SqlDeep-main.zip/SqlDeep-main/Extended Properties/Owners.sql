EXEC sp_addextendedproperty N'Owners', N'<owners>
	<owner department="SQL Deep team" developer = "Siavash Golchoobian" phone="+989123893915" mobile="+989123893915" email="siavash.golchoobian@gmail.com"/>
</owners>', NULL, NULL, NULL, NULL, NULL, NULL
GO
