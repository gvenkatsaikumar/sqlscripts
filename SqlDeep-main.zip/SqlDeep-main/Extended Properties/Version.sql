EXEC sp_addextendedproperty N'Version', N'3.0.0.0', NULL, NULL, NULL, NULL, NULL, NULL
GO
