EXEC sp_addextendedproperty N'_AlwaysOnLinkedServers', N'<linkedservers>
	<linkedserver name="LinkedServerName01"/>
	<linkedserver name="LinkedServerName02"/>
</linkedservers>', NULL, NULL, NULL, NULL, NULL, NULL
GO
