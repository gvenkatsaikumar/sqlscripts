-- causes a procedure to be recompiled next execution

exec sp_recompile 'My Stored Procedure Name'
go