-- clear ad hoc and prepared plans from the plan cache

dbcc freesystemcache('sql plans')